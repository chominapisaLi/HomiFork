ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Ящик"
ENT.Author = "thebogler"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.Category = "Homiforked | Ящики"
